#!/bin/bash
clear

sudo /usr/sbin/softwareupdate --ignore "macOS Catalina"
defaults write com.apple.systempreferences AttentionPrefBundleIDs 0
killall Dock
