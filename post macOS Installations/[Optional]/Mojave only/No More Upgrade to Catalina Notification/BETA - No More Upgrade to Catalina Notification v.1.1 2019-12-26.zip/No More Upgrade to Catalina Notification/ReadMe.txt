This is a one-(double) click implementation of Rob Griffiths' "Remove the macOS Catalina guilt trip from macOS Mojave" over at https://robservatory.com/remove-the-macos-catalina-guilt-trip-from-macos-mojave/ on his awesome macOS repertoire "The Robservatory". Just hit Install, input your password, hit ENTER/ RETURN, and that should be it.

I added 'RunAtLoad' to the property list so it runs immediately during install, and on account log-in.

The launch agent runs on a per user basis.

If you still get a Upgrade to Catalina notification with Rob's "every day at 6am, noon, and 6pm" settings: I also supplied 4, 5 and 6 hrs scripts in the InstallerData folder. Simply copy the desired launch agent one level higher and run 'Install' again.

A uninstaller is included, too.

For remarks etc. please comment over at Rob's page linked above.

Let's keep dwelling in Hayikwiir Mat'aar :)
Lee / Bux

v.1.0 2019-11-30